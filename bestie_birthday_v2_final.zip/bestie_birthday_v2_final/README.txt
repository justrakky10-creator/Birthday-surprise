BESTIE BIRTHDAY WEBSITE — VERSION 2

1. Keep the whole folder together.
2. Open the folder in VS Code.
3. Open index.html in a browser.
4. All photos are local inside images/.
5. No external fonts or image services are used in this version.
6. Edit the text in index.html when you are ready to personalize names, memories and the letter.
